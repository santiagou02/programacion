# este repositorio sirve para resolver circuitos RLC en serie y en paralelo
